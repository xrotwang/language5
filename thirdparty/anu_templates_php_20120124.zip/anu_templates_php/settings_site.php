<?php // Site Settings Template version 3.3

// Details about your website - update these on first use
// -----------------------------------------------------------------------------

$id					= '***the id number for your website***';
$SiteShortName		= '***The name of your site, for use in the menu and search headings, and in title tags for all your pages***';
$RespOfficer		= '***the position title of the person responsible for the website***';
$RespOfficerContact	= '***the contact point for your responsible officer. can be a http link or a mailto link - eg. mailto:responsible.officer@anu.edu.au***';
$SiteContactName	= '***name of the contact for enquiries about the website***';
$SiteContact		= '***the contact point for enquiries about the website. can be a http link or a mailto link - eg. mailto:contact.point@anu.edu.au***';
$MenuFile			= '***path to the menu file, starting from the root of your web server - eg. /_anu/guide/menu.php***';
$AboutPage			= '***path to the About this Site page - leave blank if none exists***';
$Analytics			= '***insert any code needed for page tracking and analytics - leave blank if none exists***';
$BodyBanner			= '<div id="devlmsg">THIS IS THE DEVELOPMENT VERSION OF THIS SITE</div>';

// Add code here to insert custom CSS or other metadata
// -----------------------------------------------------------------------------
// e.g. $Extra_Meta	= '<link media="screen" type="text/css" rel="stylesheet" href="forms.css"/>';
$Extra_Meta			= '';

// Global querystring variable
// -----------------------------------------------------------------------------
$qs_arg				= '';

// Search - replace False with True if you would like a search box in the top left of your website menu
// -----------------------------------------------------------------------------
$DisplaySearch		= False;

// Customise the search box
$SearchBox			= '';

// Custom SSL port -- If you use a non standard port for ssl to your site, you will need to specify it here.
// -----------------------------------------------------------------------------
$custom_ssl_port	= 443;

?>