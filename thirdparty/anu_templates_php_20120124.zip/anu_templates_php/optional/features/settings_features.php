<?php // Features Settings Template version 3.3

// Feature Pages
// -----------------------------------------------------------------------------

$feature_array		= array(
// start of feature 1 //
array(
	"title"		=>	"***title of feature***",
	"excerpt"	=>	"***summary of feature***",
	"url"		=>	"***url for more details on the feature. for example: http://www.anu.edu.au/wellbeing.php***",
	"image"		=>	"***file location of feature image. for example: features/wellbeing-week.jpg***"),                            
// start of feature 2 //
array(
	"title"		=>	"***title of feature***",
	"excerpt"	=>	"***summary of feature***",
	"url"		=>	"***url for more details on the feature. for example: http://www.anu.edu.au/wellbeing.php***",
	"image"		=>	"***file location of feature image. for example: features/wellbeing-week.jpg***"),
// start of feature 3 //
array(
	"title"		=>	"***title of feature***",
	"excerpt"	=>	"***summary of feature***",
	"url"		=>	"***url for more details on the feature. for example: http://www.anu.edu.au/wellbeing.php***",
	"image"		=>	"***file location of feature image. for example: features/wellbeing-week.jpg***"),
// start of feature 4 //	
array(
	"title"		=>	"***title of feature***",
	"excerpt"	=>	"***summary of feature***",
	"url"		=>	"***url for more details on the feature. for example: http://www.anu.edu.au/wellbeing.php***",
	"image"		=>	"***file location of feature image. for example: features/wellbeing-week.jpg***"),
// start of feature 5 //
array(	
	"title"		=>	"***title of feature***",
	"excerpt"	=>	"***summary of feature***",
	"url"		=>	"***url for more details on the feature. for example: http://www.anu.edu.au/wellbeing.php***",
	"image"		=>	"***file location of feature image. for example: features/wellbeing-week.jpg***"),
);
// end of features array //

    $feature_array_wide		= array(
                                // start of feature 1 //
                                array(
                                      "title"		=>	"***title of feature***",
                                      "excerpt"	=>	"***summary of feature***",
                                      "url"		=>	"***url for more details on the feature. for example: http://www.anu.edu.au/wellbeing.php***",
                                "image-w"	=> "If you use a wide feature, put different image URLs here with correct image sizes - 320x160px"),                        
                                
                                // start of feature 2 //
                                array(
                                      "title"		=>	"***title of feature***",
                                      "excerpt"	=>	"***summary of feature***",
                                      "url"		=>	"***url for more details on the feature. for example: http://www.anu.edu.au/wellbeing.php***",
                                "image-w"	=> "If you use a wide feature, put different image URLs here with correct image sizes - 320x160px"),
                                // start of feature 3 //
                                array(
                                      "title"		=>	"***title of feature***",
                                      "excerpt"	=>	"***summary of feature***",
                                      "url"		=>	"***url for more details on the feature. for example: http://www.anu.edu.au/wellbeing.php***",
                                "image-w"	=> "If you use a wide feature, put different image URLs here with correct image sizes - 320x160px")
                                
                                );
    // end of features array //

    $feature_array_narrow		= array(
                                // start of feature 1 //
                                array(
                                      "title"		=>	"***title of feature***",
                                      "excerpt"	=>	"***summary of feature***",
                                      "url"		=>	"***url for more details on the feature. for example: http://www.anu.edu.au/wellbeing.php***",
                                "image-n"	=> "If you use a narrow feature, put different image URLs here with correct image sizes - 200x200px" ),                       
                                
                                // start of feature 2 //
                                array(
                                      "title"		=>	"***title of feature***",
                                      "excerpt"	=>	"***summary of feature***",
                                      "url"		=>	"***url for more details on the feature. for example: http://www.anu.edu.au/wellbeing.php***",
                                "image-n"	=> "If you use a narrow feature, put different image URLs here with correct image sizes - 200x200px" ),
                                // start of feature 3 //
                                array(
                                      "title"		=>	"***title of feature***",
                                      "excerpt"	=>	"***summary of feature***",
                                      "url"		=>	"***url for more details on the feature. for example: http://www.anu.edu.au/wellbeing.php***",
                                "image-n"	=> "If you use a narrow feature, put different image URLs here with correct image sizes - 200x200px" ),
                                // start of feature 4 //	
                                array(
                                      "title"		=>	"***title of feature***",
                                      "excerpt"	=>	"***summary of feature***",
                                      "url"		=>	"***url for more details on the feature. for example: http://www.anu.edu.au/wellbeing.php***",
                                "image-n"	=> "If you use a narrow feature, put different image URLs here with correct image sizes - 200x200px") 
                               
                                );
    // end of features array //

    $feature_array_ticker		= array(
                                // start of feature 1 //
                                array(
                                      "title"		=>	"***title of feature***",
                                      "excerpt"	=>	"***summary of feature***",
                                      "url"		=>	"***url for more details on the feature. for example: http://www.anu.edu.au/wellbeing.php***"),
                                
                                // start of feature 2 //
                                array(
                                      "title"		=>	"***title of feature***",
                                      "excerpt"	=>	"***summary of feature***",
                                      "url"		=>	"***url for more details on the feature. for example: http://www.anu.edu.au/wellbeing.php***"),
                                // start of feature 3 //
                                array(
                                      "title"		=>	"***title of feature***",
                                      "excerpt"	=>	"***summary of feature***",
                                      "url"		=>	"***url for more details on the feature. for example: http://www.anu.edu.au/wellbeing.php***"),
                                // start of feature 4 //	
                                array(
                                      "title"		=>	"***title of feature***",
                                      "excerpt"	=>	"***summary of feature***",
                                      "url"		=>	"***url for more details on the feature. for example: http://www.anu.edu.au/wellbeing.php***")
                                );
    // end of features array //

    
    
?>