<?php  // Features Template version 3.3
    
require_once('settings_features.php');

    echo '<script type="text/javascript" src="http://styles.anu.edu.au/_anu/3/scripts/anu-feature-jq.js"></script>';

    
    function printFeaturesOrig() {
        global $feature_array;
        
        if(is_array($feature_array)){
            $home_features = '
            <div id="anu-features-rotating" class="noprint" onmouseover="pauseFeatureTimer();" onmouseout="playFeatureTimer();" >';
            $i=1;
            foreach($feature_array as $ft){
                $home_features .= '
                <div id="feature-'.$i.'" class="feature-box" >
                <div class="feature-image"><img src="'.$ft['image'].'" height="215px" width="320px" title="' . $ft['title'] . '"  alt="' . $ft['title'] . '"/>
                </div>';
                if(!isset ($ft['noANU'] ) || $ft['noANU'] != "true") {
                    $home_features .= '<div class="feat-letters"  >
                    <img class="feat-letters-png" src="http' . $sslarg . '://styles.anu.edu.au/_anu/3/images/features/anu_window_text_white.png" height="215px" width="320px" title="' . $ft['title'] . '"  alt="' . $ft['title'] . '"/>
                    <img class="feat-letters-gif" style="display:none" src="http' . $sslarg . '://styles.anu.edu.au/_anu/3/images/features/anu_window_text_white.gif" height="215px" width="320px" title="' . $ft['title'] . '"  alt="' . $ft['title'] . '"/>
                    </div>';
                }
                $home_features .=  '<div class="feature-text" id="feature-text-'.$i.'">
                <h2>'.$ft['title'].'</h2>
                <p>'.$ft['excerpt'].'</p>';
                if($ft['url']){$home_features .= '<p class="feat-more">&raquo; <a href="'.$ft['url'].'">read more</a></p>';}
                $home_features .= '
                </div>
                </div>';
                $i++;
            }
            if(count($feature_array)>1){
                $i=1;
                $home_features .= '
                <div id="features-nav-rotating">
                <ul>';
                foreach($feature_array as $ft){
                    $home_features .= '
                    <li><a href="javascript: showFeature(\''.$i.'\');" id="feature-link-'.$i.'"';
                    if($i==1){$home_features .= ' class="linkselect" ';}
                    $home_features .= '>'.$i.'</a></li>';
                    $i++;
                }
                $home_features .= '
                <li><a href="javascript: pausePlayFeatures();" style="border:0;background-color:white">
                <img width="18px" src="http' . $sslarg . '://styles.anu.edu.au/_anu/images/icons/pause2.png" id="anu-feature-playpause"  alt="Pause" title="Pause" />
                </a></li>';
                
                $home_features .= '
                </ul>
                </div>';
            }
            $home_features .= '
            </div>
            ';
            
            echo $home_features;
        }
    }	
    
    function printFeaturesNoWindow() {
        global $feature_array;
        
        if(is_array($feature_array)){
            $home_features = '
            <div id="anu-features-rotating-2" class="noprint" onmouseover="pauseFeatureTimer(\'rotating-2\');" onmouseout="playFeatureTimer(\'rotating-2\');" >';
            $i=1;
            foreach($feature_array as $ft){
                $home_features .= '
                <div id="feature-'.$i.'" class="feature-box" >';
                
                $home_features .=  '<div class="feature-text" id="feature-text-'.$i.'">
                <h2>'.$ft['title'].'</h2>
                <p>'.$ft['excerpt'].'</p>';
                if($ft['url']){$home_features .= '<p class="feat-more">&raquo; <a href="'.$ft['url'].'">read more</a></p>';}
                
                $home_features .= '
                </div>
                
                <div class="feature-image"><img src="'.$ft['image'].'" height="215px" width="320px" title="' . $ft['title'] . '"  alt="' . $ft['title'] . '"/>
                </div>';
                
                
                $home_features .= '
                </div>';
                $i++;
            }
            if(count($feature_array)>1){
                $i=1;
                $home_features .= '
                <div id="features-nav-rotating-2">';
                
                $home_features .= '<ul>';
                foreach($feature_array as $ft){
                    $home_features .= '
                    <li><a href="javascript: showFeature(\''.$i.'\',\'rotating-2\');" id="feature-link-'.$i.'"';
                    if($i==1){$home_features .= ' class="linkselect" ';}
                    $home_features .= '>'.$i.'</a></li>';
                    $i++;
                }
                $home_features .= '
                <li><a href="javascript: pausePlayFeatures(\'rotating-2\');" style="border:0;background-color:white">
                <img width="18px" src="http' . $sslarg . '://styles.anu.edu.au/_anu/images/icons/pause2.png" id="anu-feature-playpause"  alt="Pause" title="Pause" />
                </a></li>';
                
                $home_features .= '
                </ul>
                </div>';
                
            }
            $home_features .= '
            </div>
            ';
            
            echo $home_features;
            
        }	
        
        
        
        
    }
    
    function printFeaturesVertical($width) {
        global $feature_array_wide;
        global $feature_array_narrow;
        
        $use_array = $feature_array_narrow;
        
        
        if (!isset ($width)) { $width = '';}
        if ($width != '-w' && $width != '' && $width != '-g' && $width != '-wg') { $width = '';}
        
        $bgbox = ""; $emg = '';
        if ($width == '-g') {  $bgbox = ' style="background-color:#EBEBEB" '; $emg = ' style="margin: 0 10px 0 10px;" '; $width = ''; }
        if ($width == '-wg') {  $bgbox = ' style="background-color:#EBEBEB" ';$emg = ' style="margin: 0 10px 0 10px;" '; $width = '-w'; }
       
        if ($width == '-w') {
            $use_array = $feature_array_wide;
            
        }
        
        
        if(is_array($use_array)){
            $home_features = '
            <div id="anu-features-vertical' . $width . '" class="noprint" onmouseover="pauseFeatureTimer(\'vertical' . $width . '\');" onmouseout="playFeatureTimer(\'vertical' . $width . '\');" >';
            $i=1;
            foreach($use_array as $ft){
                $home_features .= '
                <div id="feature-'.$i.'" class="feature-box" ' . $bgbox . '>';              
                
                if ($width == '-w'){ 
					$home_features .= '<div class="feature-image"><img src="'.$ft['image-w'].'"';
					$home_features .= ' height="160px" width="320px" '; 
                } else {
					$home_features .= '<div class="feature-image"><img src="'.$ft['image-n'].'"';
                    $home_features .= ' height="200px" width="200px" '; 
                }
                
                $home_features .= 'title="' . $ft['title'] . '"  alt="' . $ft['title'] . '"/>
                </div>';
                
                $home_features .=  '<div class="feature-text" id="feature-text-'.$i.'" >
                <h2 ' . $emg . '>'.$ft['title'].'</h2>
                <p  ' . $emg . '>'.$ft['excerpt'].'</p>';
                if($ft['url']){$home_features .= '<p  ' . $emg . ' class="feat-more">&raquo; <a href="'.$ft['url'].'">read more</a></p>';}
                
                $home_features .= '
                </div>
                
                ';
                
                
                $home_features .= '
                </div>';
                $i++;
            }
            if(count($use_array)>1){
                $i=1;
                $home_features .= '
                <div id="features-nav-vertical' . $width .'">';
                
                if ($align == 'right') {
                    $home_features .= '<div class="right">';
                }
                
                $home_features .= '<ul>
                <li><a href="javascript: showPrevFeature(\'vertical' . $width . '\');" style="border:0">
                <img width="18px" src="http' . $sslarg . '://styles.anu.edu.au/_anu/images/icons/laquobutton.png" alt="Previous" title="Previous" />
                </a></li>
                <li><a href="javascript: pausePlayFeatures(\'vertical' . $width . '\');" style="border:0">
                <img width="18px" src="http' . $sslarg . '://styles.anu.edu.au/_anu/images/icons/pause2.png" id="anu-feature-playpause"  alt="Pause" title="Pause" />
                </a></li>
                <li><a href="javascript: showNextFeature(\'vertical' . $width . '\');" style="border:0">
                <img width="18px" src="http' . $sslarg . '://styles.anu.edu.au/_anu/images/icons/raquobutton.png"  alt="Next" title="Next" />
                </a></li>
                </ul>
                </div>';
                if ($align == 'right'){
                    $home_features .= '</div>';
                }
            }
            $home_features .= '
            </div>
            ';
            
            echo $home_features;
            
        }	
        
        
        
        
    }
    
    function printFeaturesTicker() {
        global $feature_array_ticker;
        
        if(is_array($feature_array_ticker)){
            $home_features = '
            <div id="anu-features-ticker" class="noprint" onmouseover="pauseFeatureTimer(\'ticker\');" onmouseout="playFeatureTimer(\'ticker\');" >';
            $i=1;
            
            foreach($feature_array_ticker as $ft){
                $home_features .= '
                <div id="feature-'.$i.'" class="feature-box">
                
                <div class="feature-text" id="feature-text-' . $i . '">
            <h2>News: <a href="' . $ft['url'] . '">' . $ft['title']  .'</a></h2>
                <p>' . $ft['excerpt'] . '</p>
                
                </div>
                
                </div>
                ';
                
                $i++;
            }
            
            $home_features .= ' <div class="features-fade"></div>';
            
            
            if(count($feature_array_ticker)>1){
                $i=1;
                $home_features .= '
                <div id="features-nav-ticker">';
                
                $home_features .= '<ul>
                <li><a href="javascript: showPrevFeature(\'ticker\');" style="border:0">
                <img width="18px" src="http' . $sslarg . '://styles.anu.edu.au/_anu/images/icons/laquobutton.png" alt="Previous" title="Previous" />
                </a></li>
                <li><a href="javascript: pausePlayFeatures(\'ticker\');" style="border:0">
                <img width="18px" src="http' . $sslarg . '://styles.anu.edu.au/_anu/images/icons/pause2.png" id="anu-feature-playpause"  alt="Pause" title="Pause" />
                </a></li>
                <li><a href="javascript: showNextFeature(\'ticker\');" style="border:0">
                <img width="18px" src="http' . $sslarg . '://styles.anu.edu.au/_anu/images/icons/raquobutton.png"  alt="Next" title="Next" />
                </a></li>
                </ul>
                </div>';
                
            }
            $home_features .= '
            </div>
            ';
            
            echo $home_features;
            
        }	
        
        
        
        
    }
    

?>