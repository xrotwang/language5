<?php // ANU RSS Example

include ('rss_functions.php');
	
// Some RSS feeds to read from ANU billboard and ANU News.  You will most likely want to change the areaid number to be more specific for your site.
// You can generate as many of these as you like - just give them different variable names. 
// Make sure to put the same URL in the link below for the RSS icon.  

//NOTE:  Some RSS feeds take a few seconds to be returned from their server.  If you add such an RSS feed to 
	// your page, it will slow down the time for your page to load in a browser.  Make sure you test any RSS feeds
	// that you plan to use, and if you find they are too slow to use, you may have to consider another method of 
	// including the RSS information - such as hourly downloading it and caching it locally on your site or in a database.
	
$rss_url1 = "http://anubis.anu.edu.au/billboard/rss_feed_news.asp?areaid=361";
$list1 = output_rss(get_rss($rss_url1,3,true,true));

$rss_url2 = "http://anubis.anu.edu.au/billboard/rss_feed_events.asp?areaid=412";
$list2 = output_rss(get_rss($rss_url2,3,true,true));

$rss_url3 = "http://news.anu.edu.au/?feed=rss2&cat=22";
$list3 = output_rss(get_rss($rss_url3,5,true,true));

?>

<div class="box-solid">
<p class="hdr-gold nopadtop">What's happening?</p>
<p class="hdr-grey"><a class="noprint" href="<?php echo $rss_url1 ?>"><img src="http://styles.anu.edu.au/_anu/images/icons/rss.png" class="right" alt="RSS feed for Staff Notices" width="12" height="12" /></a>Notices</p>
<ul class="linklist">
<?php echo $list1; ?>
</ul>
<p class="readmore">&raquo; <a href="http://billboard.anu.edu.au/news.asp">more notices</a></p>

<div class="divline-solid"></div>

<p class="hdr-grey"><a class="noprint" href="<?php echo $rss_url2 ?>"><img src="http://styles.anu.edu.au/_anu/images/icons/rss.png" class="right" alt="RSS feed for Staff Events" width="12" height="12" /></a>Events</p>
<ul class="linklist">
<?php echo $list2; ?>
</ul>
<p class="readmore">&raquo; <a href="http://billboard.anu.edu.au/events.asp">more events</a></p>

<div class="divline-solid"></div>

<p class="hdr-grey"><a class="noprint" href="<?php echo $rss_url3 ?>"><img src="http://styles.anu.edu.au/_anu/images/icons/rss.png" class="right" alt="RSS feed for Press Releases" width="12" height="12" /></a>ANU News</p>
<ul class="linklist">
<?php echo $list3; ?>
</ul>
<p class="readmore">&raquo; <a href="http://news.anu.edu.au/">more news</a></p>

</div>
