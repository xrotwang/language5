<?php

//date_default_timezone_set("Australia/Canberra");	
//setlocale(LC_TIME,"en_AU");

require_once('rss_lib.php');


function get_rss($rss_feed,$limit,$show_desc,$show_date){
// USAGE:
//    $rss_feed		= URL
//    $limit		= number of items to display
//    $show_desc	= (true/false) show description
//    $show_date	= (true/false) show publication date
//
// RETURNS:
//    HTML list items

	$rss = new rss_php;
	$rss->load($rss_feed);
	$items = $rss->getItems(false,$limit);
	$list = array();
	for ( $i = 0; $i < $limit ; ++$i ) {
		if ($i < count($items)) {
			$list[$i]['title']		= DoHTMLEntities($items[$i]['title']);
			$list[$i]['url']		= $items[$i]['link'];
			if($show_desc){
				$list[$i]['desc']	= DoHTMLEntities($items[$i]['description']);
			}
			if($show_date){
				if($items[$i]['pubDate']){
					$itemdate		= DoFormatDate($items[$i]['pubDate']);
				} elseif($items[$i]['dtFrom']) {
					list($day, $month, $year) = explode('/', $items[$i]['dtFrom']); 
					$usdate = $month.'/'.$day.'/'.$year; 
					$itemdate		= DoFormatDate($usdate);
				} else {
					$itemdate		= "";
				}
				$list[$i]['pubdate'] = $itemdate;
			}
		}								
	}
	return $list;
}
	
function output_rss($rss_array) {
	
	$list = "";
	foreach($rss_array as $items){
		$list .= '<li><a href="'.$items['url'].'">'.$items['title'].'</a>';
		if($items['pubdate']){ $list .= "\n".'<br/>'.$items['pubdate']; }
		if($items['desc']){ $list .= "\n".'<br/>'.$items['desc']; }
		$list .= '</li>'."\n"; 
	}
	return $list;

}

function DoHTMLEntities($string) {

	$newstring = $string ; 

	// or use the following if your PHP config allows it: 
	// $newstring = mb_convert_encoding($string,'HTML-ENTITIES','UTF-8');
	
	// LONG VERSION
	$search  = Array(
		" & ",
		chr(212),
		chr(213),
		chr(210),
		chr(211),
		chr(209),
		chr(208),
		chr(201),
		chr(145),
		chr(146),
		chr(147),
		chr(148),
		chr(151),
		chr(150),
		chr(133),
		chr(0xe2) . chr(0x80) . chr(0x98),
		chr(0xe2) . chr(0x80) . chr(0x99),
		chr(0xe2) . chr(0x80) . chr(0x9c),
		chr(0xe2) . chr(0x80) . chr(0x9d),
		chr(0xe2) . chr(0x80) . chr(0x93),
		chr(0xe2) . chr(0x80) . chr(0x94),
		chr(0xe2) . chr(0x80) . chr(0xa6)
	);
		
	$replace = Array(
		' &amp; ',
		'&lsquo;',
		'&rsquo;',
		'&ldquo;',
		'&rdquo;',
		'&ndash;',
		'&mdash;',
		'&hellip;',
		'&lsquo;',
		'&rsquo;',
		'&ldquo;',
		'&rdquo;',
		'&ndash;',
		'&mdash;',
		'&hellip;',
		'&lsquo;',
		'&rsquo;',
		'&ldquo;',
		'&rdquo;',
		'&ndash;',
		'&mdash;',
		'&hellip;'
	);
	$finalstring = str_replace($search, $replace, $newstring);
	return $finalstring;

} 

function DoFormatDate($datestring) {

	$newdatestring = date('j F, Y',strtotime($datestring)); 
	return $newdatestring;
	
}

?>


