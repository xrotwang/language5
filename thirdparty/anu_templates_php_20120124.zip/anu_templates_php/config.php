<?php // Config Template version 3.3

// explicit header information
header('Content-Type: text/html; charset=utf-8');

global $qs_arg, $sslarg;

require_once('settings_site.php');

$RespOfficerContact	= ( (strpos($RespOfficerContact,chr(64)) !== false) && (strpos($RespOfficerContact,"mailto:") === false) ) ? 'mailto:'.$RespOfficerContact : $RespOfficerContact ;
$SiteContact		= ( (strpos($SiteContact,chr(64)) !== false) && (strpos($SiteContact,"mailto:") === false) ) ? 'mailto:'.$SiteContact : $SiteContact ;

// Set version style if required
if( isset($_GET['ver']) || isset($_POST['ver']) ) {
	$ver = ( isset($_POST['ver']) ) ? $_POST['ver'] : $_GET['ver'];
	$qs_arg .= "&ver=".$ver;
}
    
     $qs_arg .= "&appid=3.3-20120124";

// Set the ssl argument if the connection to this site is via ssl.
$https_arg		= "";
if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') {
	$https_arg = "&ssl=1";
}
if ($_SERVER['SERVER_PORT'] == 443) {
	$https_arg = "&ssl=1";
}
if ($_SERVER['SERVER_PORT'] == $custom_ssl_port) {  // custom port
	$https_arg = "&ssl=1";
}
$qs_arg .= $https_arg; 

if(!strpos($qs_arg,"ssl=")===false){
	$sslarg		= "s";
} else {
	$sslarg		= "";
}

$ctx			= stream_context_create( array('http' => array('header' => 'Connection: close')));
$SiteURL		= file_get_contents('http://styles.anu.edu.au/_anu/include.php?part=site&id='.$id.$qs_arg,false,$ctx); 
$DocType		= '
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
';
$Meta			= file_get_contents('http://styles.anu.edu.au/_anu/include.php?part=meta&id='.$id.$qs_arg,false,$ctx); 
$Head			= '
<head>
<title>'.$title.' - '.$SiteShortName.' - ANU</title>
<meta name="DC.title" content="'.$title.' - '.$SiteShortName.' - ANU" />
<meta name="DC.identifier" scheme="URI" content="http://'.$_SERVER['SERVER_NAME'].htmlentities($_SERVER['PHP_SELF']).'" />
<meta name="DC.description" content="'.$description.'" />
<meta name="DC.subject" content="'.$subject.'" />
<meta name="DC.date.modified" scheme="ISO8601" content="'.date("Y-m-d", getlastmod()).'" />
<meta name="DC.date.review" scheme="ISO8601" content="'.date("Y-m-d", mktime(0,0,0,date('m',getlastmod()),date('d',getlastmod()),date('Y',getlastmod())+1)).'" />
<meta name="DC.creator" content="'.$RespOfficer.'" />
<meta name="DC.creator.email" content="'.$RespOfficerContact.'" />
<meta name="description" content="'.$description.'" />
<meta name="subject" content="'.$subject.'" />
<meta name="keywords" content="'.$subject.'" />
'.$Meta."\n".$Extra_Meta."\n";
$Body			= '</head><body>'.$BodyBanner;
$Banner			= file_get_contents('http://styles.anu.edu.au/_anu/include.php?part=banner&id='.$id.$qs_arg,false,$ctx);
$Menu			= $_SERVER['DOCUMENT_ROOT'].$MenuFile;
$About			= ($AboutPage) ? '<span class="right noprint"><a href="'.$AboutPage.'"><strong>about this site</strong></a></span>' : '' ;
if($SearchBox == ''){
	$SearchBox	= '
			<div class="search-box">
				<p>Search '.$SiteShortName.'</p>
				<form action="http://search.anu.edu.au/search/search.cgi" method="post">
				<div>
				<input name="scope" type="hidden" value="'.$SiteURL.'" />
				<input name="collection" type="hidden" value="anu_search" />
				<label for="local-query"><span class="nodisplay">Search query</span></label><input class="search-query" name="query" id="local-query" size="15" type="text" value="" />
				<label for="search"><span class="nodisplay">Search</span></label><input class="search-button" id="search" title="Search" type="submit" value="GO" /><br/>
				<a href="http://search.anu.edu.au/search/search.cgi?collection=anu_search&amp;form=advanced&amp;scope='.$SiteURL.'">Advanced search</a>
				</div>
				</form>
			</div>
';
}
$Update			= '
</div>
<!-- noindex --> 
<div id="update-wrap">
	<div id="update-details">		
		<p class="sml-hdr">
			'.$About.'  
			Updated:&nbsp;&nbsp;<strong>'.date("j F Y", getlastmod()).'</strong><span class="hpad">/</span>Responsible Officer:&nbsp;&nbsp;<a href="'.$RespOfficerContact.'"><strong>'.$RespOfficer.'</strong></a> <span class="hpad">/</span>Page Contact:&nbsp;&nbsp;<a href="'.$SiteContact.'"><strong>'.$SiteContactName.'</strong></a>
		</p> 
	</div>
</div>
<!-- endnoindex --> 	
';
$Footer			= file_get_contents("http://styles.anu.edu.au/_anu/include.php?part=footer".$qs_arg,false,$ctx).'
<script type="text/javascript" src="http'.$sslarg.'://styles.anu.edu.au/_anu/3/scripts/anu-menu.js"></script>
</body>
</html>
';
 		
?>