<?php // Page Template version 3.3

// PLEASE UPDATE THESE VALUES FOR EVERY PAGE
// -----------------------------------------------------------------------------
$title			= '***title of this page***';
$description	= '***description of this page***';
$subject		= '***keywords describing the content of this page, separated with commas***';

// Include configuration file & begin the XHTML response
// -----------------------------------------------------------------------------
include ($_SERVER['DOCUMENT_ROOT'] .'***path to the config file, starting from the root of your web server - eg. /_anu/guide/config.php***'); 

echo $DocType; 
echo $Head; 
// insert additional header statements here //
echo $Body;
echo $Banner; 
include $Menu;


// BEGIN: Page Content
// =============================================================================
?>
<!-- START MAIN PAGE CONTENT -->	


	<div class="***choose the layout class you need - eg.narrow, doublenarrow, wide, doublewide***">
		<h1><?php echo $title; ?></h1>
		<p>***Enter your page content***</p>
	</div>	
	

<!-- END MAIN PAGE CONTENT -->
<?php 
// =============================================================================
// END: Page Content


// Complete the XHTML response
// -----------------------------------------------------------------------------
echo $Update; 
echo $Analytics;
echo $Footer; 

?>
